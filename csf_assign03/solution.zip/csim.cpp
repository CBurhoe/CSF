#include <iostream>
#include "cache_structure.h"

void hello() {
  std::cout << "Hello, World!" << std::endl;
}
