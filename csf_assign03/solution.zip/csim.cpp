#include <iostream>
#include "cache_structure.h"

int main(int argc, char **argv) {
  //TODO: Implement
  return 0;
}