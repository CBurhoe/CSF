TODO: add information about contributions of team member(s)
All functions implemented by me, Casey Burhoe.