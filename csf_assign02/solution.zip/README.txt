TODO: add information about contributions of team member(s)
All functions implemented by me, Casey Burhoe.

I was unable to exhaustively finish wc_find_or_insert,
wc_dict_find_or_insert, or main in assembly. For some unknown reason, my
hashcode was not mapping onto the right index for the third wordentry inserted
into the dictionary. Otherwise, the rest of the functions were fully
functional.