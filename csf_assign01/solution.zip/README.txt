TODO: add information about contributions of team member(s)
Implemented the createuint256, createuint265_from_uint32, and getbits functions by myself.
Also implemented the add, subtract, and negate functiosn by myself (misunderstood what was included in MS1).
